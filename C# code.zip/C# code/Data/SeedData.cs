using OmanHotelBooking.Models;

namespace OmanHotelBooking.Data
{
    public static class SeedData
    {
        public static void Initialize(ApplicationDbContext context)
        {
            // Check if rooms already exist
            if (context.Rooms.Any())
            {
                return; // Database has been seeded
            }

            // Seed 3 room types
            var rooms = new Room[]
            {
                new Room
                {
                    Name = "Deluxe Suite",
                    Type = "Suite",
                    PricePerNight = 150.00M,
                    Description = "Spacious suite with sea view, king-size bed, and modern amenities. Perfect for couples.",
                    IsAvailable = true
                },
                new Room
                {
                    Name = "Standard Room",
                    Type = "Standard",
                    PricePerNight = 80.00M,
                    Description = "Comfortable room with queen-size bed, AC, and free WiFi. Ideal for budget travelers.",
                    IsAvailable = true
                },
                new Room
                {
                    Name = "Family Room",
                    Type = "Family",
                    PricePerNight = 120.00M,
                    Description = "Large room with two double beds, suitable for families. Includes breakfast.",
                    IsAvailable = true
                }
            };

            context.Rooms.AddRange(rooms);
            context.SaveChanges();
        }
    }
}

using System.ComponentModel.DataAnnotations;

namespace OmanHotelBooking.Models
{
    public class Booking
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Name is required")]
        public string CustomerName { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string CustomerEmail { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Check-in date is required")]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }
        
        [Required(ErrorMessage = "Check-out date is required")]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }
        
        public int RoomId { get; set; }
        public Room? Room { get; set; }
        
        public DateTime BookingDate { get; set; } = DateTime.Now;
        
        public decimal TotalPrice { get; set; }
        
        public int NumberOfNights { get; set; }
    }
}

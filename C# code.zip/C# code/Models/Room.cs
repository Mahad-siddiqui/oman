using System.ComponentModel.DataAnnotations;

namespace OmanHotelBooking.Models
{
    public class Room
    {
        public int Id { get; set; }
        
        [Required]
        public string Name { get; set; } = string.Empty;
        
        [Required]
        public string Type { get; set; } = string.Empty;
        
        [Required]
        public decimal PricePerNight { get; set; }
        
        public string Description { get; set; } = string.Empty;
        
        public bool IsAvailable { get; set; } = true;
    }
}

using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using OmanHotelBooking.Data;
using OmanHotelBooking.Models;

namespace OmanHotelBooking.Pages.Admin
{
    public class BookingsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public BookingsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Booking> Bookings { get; set; } = new List<Booking>();

        public async Task OnGetAsync()
        {
            Bookings = await _context.Bookings
                .Include(b => b.Room)
                .OrderByDescending(b => b.BookingDate)
                .ToListAsync();
        }
    }
}

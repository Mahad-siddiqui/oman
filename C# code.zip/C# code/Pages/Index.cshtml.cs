using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using OmanHotelBooking.Data;
using OmanHotelBooking.Models;

namespace OmanHotelBooking.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Room> Rooms { get; set; } = new List<Room>();

        public async Task OnGetAsync()
        {
            Rooms = await _context.Rooms
                .Where(r => r.IsAvailable)
                .ToListAsync();
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using OmanHotelBooking.Data;
using OmanHotelBooking.Models;

namespace OmanHotelBooking.Pages
{
    public class BookingModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public BookingModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Booking Booking { get; set; } = new Booking();

        public Room? Room { get; set; }

        public async Task<IActionResult> OnGetAsync(int? roomId)
        {
            if (roomId == null)
            {
                return RedirectToPage("/Index");
            }

            Room = await _context.Rooms.FindAsync(roomId);

            if (Room == null || !Room.IsAvailable)
            {
                return RedirectToPage("/Index");
            }

            Booking.RoomId = Room.Id;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            Room = await _context.Rooms.FindAsync(Booking.RoomId);

            if (Room == null)
            {
                ModelState.AddModelError(string.Empty, "Room not found.");
                return Page();
            }

            // Validation
            if (Booking.CheckInDate < DateTime.Today)
            {
                ModelState.AddModelError("Booking.CheckInDate", "Check-in date cannot be in the past.");
            }

            if (Booking.CheckOutDate <= Booking.CheckInDate)
            {
                ModelState.AddModelError("Booking.CheckOutDate", "Check-out date must be after check-in date.");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Calculate total price
            Booking.NumberOfNights = (Booking.CheckOutDate - Booking.CheckInDate).Days;
            Booking.TotalPrice = Booking.NumberOfNights * Room.PricePerNight;
            Booking.BookingDate = DateTime.Now;

            _context.Bookings.Add(Booking);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Confirmation", new { id = Booking.Id });
        }
    }
}
